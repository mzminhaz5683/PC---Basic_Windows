#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

void main()
{
    int X = 0;
    printf("This program is created by MZ (mz.minhaz5683@gmail.com).\n \n******* Program must be run in administrator mode.");
    do
    {
        system("color 07");
        printf("\n\n\n_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-__-_-_-_-_-_-_-_-_-");
        printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        printf("\nEnter any id to execute that command & Enter '0' for exit.\n\n     1. For showing drivers,\n     2. For showing network's status,\n     3. For starting Hotspot,\n     4. For stopping Hotspot,\n     5. For changing network's identity.,\n     6. For cleaning screen.\n\n     : ");
        scanf("%d", &X);
        system("COLOR 0B");
        if(X == 1)
            system("netsh wlan show drivers");
        else if(X == 2)
            system("netsh wlan show hostednetwork");
        else if(X == 3)
        {
            system("netsh wlan start hostednetwork");
            printf("All wifi must be powered on, although not connected.\n*** Note : For PC <--> Phone connection, Main wifi must be shared for the host network.\n           And on this process if the shared process dosen't work,\n             Then other wifi ports need to be disconnected before shared.\n                The ports can be reconnected after sharing process finished.");
        }
        else if(X == 4)
            system("netsh wlan stop hostednetwork");
        else if(X == 5)
        {
            char check_key[100], name[100]="Nothing_given", key[100]="Nothing_given", set[300] = "netsh wlan set hostednetwork mode=allow ssid=";
            printf("\n\nEnter name and password of the hotspot.\n     Default is 'Nothing_given' for both. [[ Password > 7 ]]\n\n         Name :  ");
            scanf("%s", &name);
            if (strcmp(name, "0") == 0)
            {
                return;
            }
            printf("     Password :  ");
            scanf("%s", &check_key);
            if (strlen(check_key)>7)
            {
                    strcpy(key, check_key);
            }
            strcat(set, name);
            strcat(set, " key=");
            strcat(set, key);
            printf("\n\nHotspot name = %s, Password = %s\n\n", name, key);
            system(set);

        }
        else if(X == 6)
        {
            system("cls");
        }
        getch();
    }while(X != 0);
}
