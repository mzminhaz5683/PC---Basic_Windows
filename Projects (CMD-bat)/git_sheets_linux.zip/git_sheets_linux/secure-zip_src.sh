cd ./manage/src
echo ">>>>>>>>>>>>>>>>>>> passwd of src >>>>>>>>>>>>>>>>>>>"
zip -P 0000 -r src.zip *.py
cd ..
cd ..
