cd ./manage/submission

echo "---------Enter name of submission file---------"
read x
mv submission_mz.csv $x.csv

cd ..
cd ..
