cd ./manage/dataset
echo ">>>>>>>>>>>>>>>>>>> passwd of dataset >>>>>>>>>>>>>>>>>>>"
zip -P 0000 -r dataset.zip *.txt
cd ..
cd ..
