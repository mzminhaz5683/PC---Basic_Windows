cd ./manage/output
echo ">>>>>>>>>>>>>>>>>>> passwd of model >>>>>>>>>>>>>>>>>>>"
zip -P 0000 -rm model.zip *.h5
cd ..
cd ..

