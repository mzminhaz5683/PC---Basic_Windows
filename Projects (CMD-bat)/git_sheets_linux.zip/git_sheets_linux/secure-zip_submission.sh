cd ./manage/submission
echo ">>>>>>>>>>>>>>>>>>> passwd of submission >>>>>>>>>>>>>>>>>>>"
zip -P 0000 -rm submision.zip *.csv
cd ..
cd ..
